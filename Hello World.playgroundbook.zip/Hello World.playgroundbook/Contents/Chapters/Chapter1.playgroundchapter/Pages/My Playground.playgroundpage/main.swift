
print("This is a hello world program")
