//
//  Message.swift
//  BookCore
//
//  Created by JiaChen(: on 16/4/21.
//

import Foundation
import NaturalLanguage

struct Message: Codable {
    var senderIsUser: Bool
    var message: String
    
    func getSentimentScore() -> Double {
        let tagger = NLTagger(tagSchemes: [.tokenType, .sentimentScore])
        tagger.string = message

        var score = 0.0
        
        tagger.enumerateTags(in: message.startIndex..<message.endIndex, unit: .paragraph,
                             scheme: .sentimentScore, options: []) { sentiment, _ in
            
            if let sentimentScore = sentiment?.rawValue, let convertedScore = Double(sentimentScore) {
                score = convertedScore
            }
            return true
        }
        
        return score
    }
}
