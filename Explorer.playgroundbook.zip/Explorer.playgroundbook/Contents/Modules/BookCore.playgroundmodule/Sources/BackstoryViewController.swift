//
//  BackstoryViewController.swift
//  BookCore
//
//  Created by JiaChen(: on 31/3/21.
//

import UIKit
import PlaygroundSupport
import SceneKit

public class BackstoryViewController: UIViewController {
    var promptView: TKRobotPromptView!
    var currentMessage = 0
    
    let messages = ["Hi, welcome to the dungeon.", "You were captured because you have access to an advanced chatbot that can solve any problem - me.", "Your goal is to escape out of this dungeon, using SwiftUI.", "Don't worry, if you need help, you can click on my profile picture to chat with me."]
    
    public override func loadView() {
        super.loadView()
        
        setUpPrompt()
    }
    
    func setUpPrompt() {
        let promptView = TKRobotPromptView(with: messages[currentMessage], sender: self)
        
        promptView.translatesAutoresizingMaskIntoConstraints = false
        
        view.addSubview(promptView)
        
        view.addConstraints([NSLayoutConstraint(item: promptView,
                                                attribute: .leading,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .leadingMargin,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: promptView,
                                                attribute: .trailing,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .trailingMargin,
                                                multiplier: 1,
                                                constant: 0),
                             NSLayoutConstraint(item: promptView,
                                                attribute: .top,
                                                relatedBy: .equal,
                                                toItem: view,
                                                attribute: .topMargin,
                                                multiplier: 1,
                                                constant: 16)])
    }
}
