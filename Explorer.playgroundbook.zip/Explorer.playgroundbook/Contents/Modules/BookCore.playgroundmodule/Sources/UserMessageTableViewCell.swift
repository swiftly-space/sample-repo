//
//  UserMessageTableViewCell.swift
//  PlaygroundBook
//
//  Created by JiaChen(: on 16/4/21.
//

import UIKit

class UserMessageTableViewCell: UITableViewCell, MessageManager {
    
    var message: Message! {
        didSet {
            messageLabel.text = message.message
        }
    }
    
    var messageLabel = UILabel()
    
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        let promptView = UIView()
        
        promptView.backgroundColor = .systemBlue
        promptView.layer.cornerRadius = 10
        promptView.clipsToBounds = true
        promptView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMaxYCorner, .layerMinXMaxYCorner]
        
        promptView.translatesAutoresizingMaskIntoConstraints = false
        
        contentView.addSubview(promptView)
        
        messageLabel.translatesAutoresizingMaskIntoConstraints = false
        messageLabel.numberOfLines = 0
        promptView.addSubview(messageLabel)
        
        contentView.addConstraints([NSLayoutConstraint(item: promptView,
                                                       attribute: .trailing,
                                                       relatedBy: .equal,
                                                       toItem: contentView,
                                                       attribute: .trailing,
                                                       multiplier: 1,
                                                       constant: -8),
                                    NSLayoutConstraint(item: promptView,
                                                       attribute: .top,
                                                       relatedBy: .equal,
                                                       toItem: contentView,
                                                       attribute: .top,
                                                       multiplier: 1,
                                                       constant: 8),
                                    NSLayoutConstraint(item: promptView,
                                                       attribute: .bottom,
                                                       relatedBy: .equal,
                                                       toItem: contentView,
                                                       attribute: .bottom,
                                                       multiplier: 1,
                                                       constant: -8),
                                    NSLayoutConstraint(item: promptView,
                                                       attribute: .width,
                                                       relatedBy: .lessThanOrEqual,
                                                       toItem: contentView,
                                                       attribute: .width,
                                                       multiplier: 2/3,
                                                       constant: 0),
                                    NSLayoutConstraint(item: messageLabel,
                                                       attribute: .top,
                                                       relatedBy: .equal,
                                                       toItem: promptView,
                                                       attribute: .top,
                                                       multiplier: 1,
                                                       constant: 12),
                                    NSLayoutConstraint(item: messageLabel,
                                                       attribute: .leading,
                                                       relatedBy: .equal,
                                                       toItem: promptView,
                                                       attribute: .leading,
                                                       multiplier: 1,
                                                       constant: 12),
                                    NSLayoutConstraint(item: messageLabel,
                                                       attribute: .trailing,
                                                       relatedBy: .equal,
                                                       toItem: promptView,
                                                       attribute: .trailing,
                                                       multiplier: 1,
                                                       constant: -12),
                                    NSLayoutConstraint(item: messageLabel,
                                                       attribute: .bottom,
                                                       relatedBy: .equal,
                                                       toItem: promptView,
                                                       attribute: .bottom,
                                                       multiplier: 1,
                                                       constant: -12)])
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
}
