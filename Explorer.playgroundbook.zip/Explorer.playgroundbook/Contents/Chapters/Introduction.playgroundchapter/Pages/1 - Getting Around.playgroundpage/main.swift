//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
//#-end-hidden-code
//: ````
//:   __,                    ,   , ____
//:  (           o  /) _/_  /   /   /
//:   `.  , , , ,  //  /   /   /;  /
//: (___)(_(_/_(_ //_ (__ (___/ (_‘__
//:              /)
//:             (/
//: ````
//: # Welcome to the Dungeon
//: Move around the dungeon and explore the space using the control buttons provided
//:
//: ![control](control)
//: - The `Left` and `Right` control buttons turns you left and right
//: - The `Forward` button moves you forward based on the direction you are facing.
