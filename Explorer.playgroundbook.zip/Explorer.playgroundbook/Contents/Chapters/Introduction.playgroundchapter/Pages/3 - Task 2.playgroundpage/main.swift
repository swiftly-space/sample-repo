//#-hidden-code
//
//  See LICENSE folder for this template’s licensing information.
//
//  Abstract:
//  The Swift file containing the source code edited by the user of this playground book.
//
import SwiftUI
import PlaygroundSupport
import BookCore

struct PieceOne: View {
    var body: some View {
        Image("01").resizable().aspectRatio(contentMode: .fit)
    }
}
struct PieceTwo: View {
    var body: some View {
        Image("02").resizable().aspectRatio(contentMode: .fit)
    }
}
struct PieceThree: View {
    var body: some View {
        Image("03").resizable().aspectRatio(contentMode: .fit)
    }
}

//#-end-hidden-code
//: ````
//:   __,                    ,   , ____
//:  (           o  /) _/_  /   /   /
//:   `.  , , , ,  //  /   /   /;  /
//: (___)(_(_/_(_ //_ (__ (___/ (_‘__
//:              /)
//:             (/
//: ````
//: # Task 2: Piece the Document
//: There are 3 buttons above, ensure that the buttons at the bottom replicates the buttons on top.
//:
//: ## Pieces
//: Here are the pieces you found. You are supposed to connect them together using `VStack`s & `HStack`s.
//:
//: ### Piece 1
//: Usage: `PieceOne()`
//: ```swift
//: VStack(spacing: 0) {
//:     PieceOne()
//: }
//: ```
//: ![3-01.png](3-01.png)
//:
//: ### Piece 2
//: Usage: `PieceTwo()`
//: ```swift
//: VStack(spacing: 0) {
//:     PieceTwo()
//: }
//: ```
//: ![3-02.png](3-02.png)
//:
//: ### Piece 3
//: Usage: `PieceThree()`
//: ```swift
//: VStack(spacing: 0) {
//:     PieceThree()
//: }
//: ```
//: ![3-03.png](3-03.png)
//:
//: > In your `HStack` and `VStack`, please set your `spacing` to 0,
//: > ```swift
//: > VStack(spacing: 0) {
//: >     // your code
//: > }
//: > ```
//:
//: > Press Run My Code and see your changes on the live view.
struct Map: View {
    var body: some View {
        //#-hidden-code
        //#-observe-1
        //#-end-hidden-code
        //#-editable-code
        /*@START_MENU_TOKEN@*/Text("Hello, world")/*@END_MENU_TOKEN@*/
        //#-end-editable-code
        //#-hidden-code
        //#-end-observe-1
        //#-end-hidden-code
    }
}

//#-hidden-code
func initialize() {
    let vc = TaskTwoViewController()
    vc.setPreview(with: UIHostingController(rootView: Map()).view)
    vc.isCurrent = String(describing: type(of: Map().body)) == "VStack<TupleView<(PieceTwo, HStack<TupleView<(PieceThree, PieceOne)>>)>>"
    PlaygroundPage.current.liveView = vc
}

initialize()
//#-end-hidden-code
